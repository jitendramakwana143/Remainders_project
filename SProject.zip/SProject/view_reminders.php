<?php
session_start();

// Check if the user is not logged in, redirect to login.php
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit;
}

// Placeholder function to fetch subjects from the database
function getSubjects() {
    // Replace with your database connection details
    // ...

    return []; // Placeholder return
}

// Placeholder function to fetch reminders based on the selected criteria
function getReminders($fromDate, $toDate, $selectedSubject) {
    // Replace with your database connection details
    // ...

    return []; // Placeholder return
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reminders</title>
    <style>
        /* Your existing CSS styles here */

        .view-reminders-container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .view-reminders-container h2 {
            margin-bottom: 20px;
        }

        .view-reminders-container label,
        .view-reminders-container select {
            display: block;
            width: 100%;
            margin-top: 10px;
            box-sizing: border-box;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .view-reminders-container button {
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        .view-reminders-container button:hover {
            background-color: #2980b9;
        }

        .reminder-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .reminder-table th,
        .reminder-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .reminder-table th {
            background-color: #3498db;
            color: white;
        }

        .success-message,
        .error-message {
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="view-reminders-container">
        <h2>View Reminders</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="fromDate">Select From Date:</label>
            <input type="date" name="fromDate" required>

            <label for="toDate">Select To Date:</label>
            <input type="date" name="toDate" required>

            <label for="selectSubject">Subject:</label>
            <select name="selectSubject">
                <option value="">All Subjects</option>
                <?php
                // Populate subjects dynamically
                $subjects = getSubjects();
                foreach ($subjects as $subject) {
                    echo "<option value='$subject'>$subject</option>";
                }
                ?>
            </select>

            <button type="submit">View Reminders</button>
        </form>

        <?php
        // Display reminders based on the selected criteria
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $fromDate = $_POST["fromDate"];
            $toDate = $_POST["toDate"];
            $selectedSubject = isset($_POST["selectSubject"]) ? $_POST["selectSubject"] : "";

            $reminders = getReminders($fromDate, $toDate, $selectedSubject);

            if (!empty($reminders)) {
                echo "<table class='reminder-table'>";
                echo "<tr><th>Reminder Name</th><th>Reminder Subject</th><th>Reminder Description</th><th>Email Address</th><th>Contact No</th><th>SMS No</th><th>Status</th><th>Recurrence Frequency</th></tr>";
                foreach ($reminders as $reminder) {
                    echo "<tr>";
                    echo "<td>{$reminder['name']}</td>";
                    echo "<td>{$reminder['subject']}</td>";
                    echo "<td>{$reminder['description']}</td>";
                    echo "<td>{$reminder['email']}</td>";
                    echo "<td>{$reminder['contact']}</td>";
                    echo "<td>{$reminder['sms']}</td>";
                    echo "<td>{$reminder['status']}</td>";
                    echo "<td>{$reminder['recurrence']}</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<div class='error-message'>No reminders found.</div>";
            }
        }
        ?>

        <div class="button">
            <button type="submit"><a href="home.php">Back</a></button>
            <button type="submit"><a href="logout.php">Logout</a></button>
        </div>
    </div>

</body>
</html>
