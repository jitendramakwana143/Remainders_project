<?php
session_start();

// Check if the user is not logged in, redirect to login.php
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit;
}


function getSubjects() {
    // Replace with your database connection details
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "remainder_system";

    $conn = new mysqli($host, $username, $password, $database);


    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $subjects = array();

    // Replace 'subjects' with the actual table name for subjects
    $sql = "SELECT subject FROM reminders";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $subjects[] = $row['subject_name'];
        }
    }

    $conn->close();

    return $subjects;
}

// Placeholder function to fetch reminders from the database based on the selected subject
function getReminders($selectedSubject) {
    // Replace with your database connection details
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "remainder_system";

    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $reminders = array();

    // Replace 'reminders' with the actual table name for reminders
    $sql = "SELECT subject FROM reminders WHERE subject = '$selectedSubject'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $reminders[] = array(
                'id' => $row['id'],
                'name' => $row['reminder_name'],
                'description' => $row['short_description']
            );
        }
    }

    $conn->close();

    return $reminders;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form submission
    $selectedDate = $_POST["selectDate"];
    $selectedSubject = $_POST["selectSubject"];

    $recur = isset($_POST["recur"]) ? $_POST["recur"] : [];

    // Process the selected checkboxes for recurrence
    $selectedRecur = implode(", ", $recur);

    // Placeholder: Process the modification in the database based on the selected data
    // ...

    // Placeholder messages
    $successMessage = "Reminder modified successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Reminder</title>
    <style>
        /* Your existing CSS styles here */

        .modify-reminder-container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
            margin-top: 20px;
        }

        .modify-reminder-container h2 {
            margin-bottom: 20px;
        }

        .modify-reminder-container label {
            display: block;
            margin-top: 10px;
        }

        .modify-reminder-container input,
        .modify-reminder-container select,
        .modify-reminder-container textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .modify-reminder-container button {
            width: 100%;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        .modify-reminder-container button:hover {
            background-color: #45a049;
        }

        .success-message,
        .error-message {
            margin-top: 10px;
        }
    /* Your existing CSS styles here */
    </style>
</head>
<body>

    <div class="modify-reminder-container">
        <h2>Modify Reminder</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="selectDate">Select Date:</label>
            <input type="date" name="selectDate" required>

            <label for="selectSubject">Select Subject:</label>
            <select name="selectSubject" required>
                <?php
                // Populate subjects dynamically
                $subjects = getSubjects();
                foreach ($subjects as $subject) {
                    echo "<option value='$subject'>$subject</option>";
                }
                ?>
            </select>

            <label for="selectReminder">Reminders:</label>
            <select name="selectReminder" required>
                <?php
                // Populate reminders dynamically based on the selected subject
                if (isset($_POST["selectSubject"])) {
                    $selectedSubject = $_POST["selectSubject"];
                    $reminders = getReminders($selectedSubject);
                    foreach ($reminders as $reminder) {
                        echo "<option value='{$reminder['id']}'>{$reminder['name']} - {$reminder['description']}</option>";
                    }
                }
                ?>
            </select>

            <label>Recur for next:</label>
            <input type="checkbox" name="recur[]" value="7"> 7 Days
            <input type="checkbox" name="recur[]" value="5"> 5 Days
            <input type="checkbox" name="recur[]" value="3"> 3 Days
            <input type="checkbox" name="recur[]" value="2"> 2 Days

            <button type="submit">Modify Reminder</button>
        </form>
        <div class="button">
            <button type="submit"><a href="home.php">Back</a></button>
            <button type="submit"><a href="logout.php">logout</a></button>
        </div>
        <?php
        if (isset($successMessage)) {
            echo "<div class='success-message'>$successMessage</div>";
        }
        if (isset($errorMessage)) {
            echo "<div class='error-message'>$errorMessage</div>";
        }
        ?>
    </div>

</body>
</html>
