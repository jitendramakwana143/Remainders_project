<?php
session_start();

// Check if the user is not logged in, redirect to login.php
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit;
}

// Placeholder function to fetch subjects from the database
function getSubjects() {
    // Replace with your database connection details
    $host = "your_database_host";
    $username = "your_database_username";
    $password = "your_database_password";
    $database = "your_database_name";

    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $subjects = array();

    // Replace 'subjects' with the actual table name for subjects
    $sql = "SELECT subject_name FROM subjects";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $subjects[] = $row['subject_name'];
        }
    }

    $conn->close();

    return $subjects;
}

// Placeholder function to fetch reminders from the database based on the selected subject
function getReminders($selectedSubject) {
    // Replace with your database connection details
    $host = "your_database_host";
    $username = "your_database_username";
    $password = "your_database_password";
    $database = "your_database_name";

    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $reminders = array();

    // Replace 'reminders' with the actual table name for reminders
    $sql = "SELECT id, reminder_name, LEFT(description, 30) as short_description FROM reminders WHERE subject_name = '$selectedSubject'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $reminders[] = array(
                'id' => $row['id'],
                'name' => $row['reminder_name'],
                'description' => $row['short_description']
            );
        }
    }

    $conn->close();

    return $reminders;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form submission
    $selectedDate = $_POST["selectDate"];
    $selectedSubject = $_POST["selectSubject"];
    $selectedReminderId = $_POST["selectReminder"];

    // Placeholder: Process the disable action in the database based on the selected data
    // ...

    // Placeholder messages
    $successMessage = "Reminder disabled successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disable Reminder</title>
    <style>
        /* Your existing CSS styles here */

        .disable-reminder-container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
            margin-top: 20px;
        }

        .disable-reminder-container h2 {
            margin-bottom: 20px;
        }

        .disable-reminder-container label {
            display: block;
            margin-top: 10px;
        }

        .disable-reminder-container input,
        .disable-reminder-container select,
        .disable-reminder-container textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .disable-reminder-container button {
            width: 100%;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        .disable-reminder-container button:hover {
            background-color: #45a049;
        }

        .success-message,
        .error-message {
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="disable-reminder-container">
        <h2>Disable Reminder</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="selectDate">Select Date:</label>
            <input type="date" name="selectDate" required>

            <label for="selectSubject">Select Subject:</label>
            <select name="selectSubject" required>
                <?php
                // Populate subjects dynamically
                $subjects = getSubjects();
                foreach ($subjects as $subject) {
                    echo "<option value='$subject'>$subject</option>";
                }
                ?>
            </select>

            <label for="selectReminder">Reminders:</label>
            <select name="selectReminder" required>
                <?php
                // Populate reminders dynamically based on the selected subject
                if (isset($_POST["selectSubject"])) {
                    $selectedSubject = $_POST["selectSubject"];
                    $reminders = getReminders($selectedSubject);
                    foreach ($reminders as $reminder) {
                        echo "<option value='{$reminder['id']}'>{$reminder['name']} - {$reminder['description']}</option>";
                    }
                }
                ?>
            </select>

            <label for="description">Description:</label>
            <textarea name="description" rows="4" readonly>
                <?php
                // Display the description based on the selected reminder
                if (isset($_POST["selectReminder"])) {
                    $selectedReminderId = $_POST["selectReminder"];
                    // Fetch the full description from the database based on the reminder ID
                    // Replace this with your actual database query
                    $fullDescription = "Placeholder for full description from the database";
                    echo $fullDescription;
                }
                ?>
            </textarea>

            <button type="submit">Disable Reminder</button>
        </form>
        <div class="button">
            <button type="submit"><a href="home.php">Back</a></button>
            <button type="submit"><a href="logout.php">Logout</a></button>
        </div>
        
        <?php
        if (isset($successMessage)) {
            echo "<div class='success-message'>$successMessage</div>";
        }
        if (isset($errorMessage)) {
            echo "<div class='error-message'>$errorMessage</div>";
        }
        ?>
    </div>

</body>
</html>
