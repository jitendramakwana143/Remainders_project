<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form has been submitted and if the expected keys are present
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $enteredUsername = $_POST["username"];
        $enteredPassword = $_POST["password"];

        // Validate and sanitize the input (you should improve this part)
        $enteredUsername = htmlspecialchars($enteredUsername);
        $enteredPassword = htmlspecialchars($enteredPassword);

        // Replace with your database connection details
        $host = "localhost";
        $username = "root";
        $password = "";
        $database = "remainder_system";

        $conn = new mysqli($host, $username, $password, $database);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Replace 'your_table_name' with the actual table name in your database
        $sql = "SELECT * FROM login_tbl WHERE username='$enteredUsername' AND password='$enteredPassword'";

        $result = $conn->query($sql);

        if ($result === false) {
            // Check for errors in your SQL query
            die("Error: " . $conn->error);
        }

        if ($result->num_rows > 0) {
            // Login successful, store username in session
            $_SESSION["username"] = $enteredUsername;

            // Redirect to welcome.php or another page
            header("Location: home.php");
            exit;
        } else {
            // Login failed
            $loginError = "Invalid username or password";
        }

        $conn->close();
    } else {
        // Handle the case where the expected keys are not present in $_POST
        $loginError = "Invalid form submission";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f2f2f2;
        }

        .login-container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        .login-container h2 {
            margin-bottom: 20px;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .login-container button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="login-container">
        <h2>Login</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <div class="error-message"><?php if(isset($loginError)) echo $loginError; ?></div>
       
    </div>
      
    

</body>
</html>
