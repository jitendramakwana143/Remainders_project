<?php
session_start();

// Check if the user is not logged in, redirect to login.php
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit;
}

// Placeholder function to fetch subjects from the database
function getSubjects() {
    // Replace with your database connection details
    // ...

    return []; // Placeholder return
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form submission
    $selectedDate = $_POST["selectDate"];
    $selectedSubject = $_POST["selectSubject"];
    $selectedRecur = isset($_POST["recur"]) ? $_POST["recur"] : [];

    // Placeholder: Process the selected checkboxes for recurrence
    $selectedRecur = implode(", ", $selectedRecur);

    // Placeholder: Process the data in the database
    // ...

    // Placeholder messages
    $successMessage = "Reminder deleted successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Reminder</title>
    <style>
        /* Your existing CSS styles here */

        .delete-reminder-container {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .delete-reminder-container h2 {
            margin-bottom: 20px;
        }

        .delete-reminder-container label,
        .delete-reminder-container select {
            display: block;
            width: 100%;
            margin-top: 10px;
            box-sizing: border-box;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .delete-reminder-container button {
            width: 100%;
            padding: 10px;
            background-color: #e74c3c;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        .delete-reminder-container button:hover {
            background-color: #c0392b;
        }

        .success-message,
        .error-message {
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="delete-reminder-container">
        <h2>Delete Reminder</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="selectDate">Select Date:</label>
            <input type="date" name="selectDate" required>

            <label for="selectSubject">Select Subject:</label>
            <select name="selectSubject" required>
                <?php
                // Populate subjects dynamically
                $subjects = getSubjects();
                foreach ($subjects as $subject) {
                    echo "<option value='$subject'>$subject</option>";
                }
                ?>
            </select>

            <label>Recur for next:</label>
            <input type="checkbox" name="recur[]" value="7"> 7 Days
            <input type="checkbox" name="recur[]" value="5"> 5 Days
            <input type="checkbox" name="recur[]" value="3"> 3 Days
            <input type="checkbox" name="recur[]" value="2"> 2 Days

            <button type="submit">Delete Reminder</button>
        </form>
        <div class="button">
            <button type="submit"><a href="home.php">Back</a></button>
            <button type="submit"><a href="logout.php">Logout</a></button>
        </div>
        <?php
        if (isset($successMessage)) {
            echo "<div class='success-message'>$successMessage</div>";
        }
        if (isset($errorMessage)) {
            echo "<div class='error-message'>$errorMessage</div>";
        }
        ?>
    </div>

</body>
</html>
