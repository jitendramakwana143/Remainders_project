
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reminder System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 600px;
            margin: auto;
            text-align: center;
            padding: 20px;
        }

        .reminder-options {
            margin-top: 20px;
        }

        .reminder-options a {
            display: block;
            margin-top: 10px;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            text-decoration: none;
        }

        .reminder-options a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="container">
      
    <center><h1>Home Page</h1></center>
   
    <center><h1>Welcome to the Reminder Application <b><?php echo '$username'?></b></h1></center>
     
    <h1>Today is <?php echo date('l, jS \of F'); ?>.</h1>

    <div class="reminder-options">
        <a href="set_reminder.php">Set Reminder</a>
        <a href="modify_reminder.php">Modify Reminder</a>
        <a href="disable_reminder.php">Disable Reminder</a>
        <a href="delete_reminder.php">Delete Reminder</a>
        <a href="enable_reminder.php">Enable Reminder</a>
        <a href="view_reminders.php">View Your Reminders</a>

       
    </div>
</div>

</body>
</html>
