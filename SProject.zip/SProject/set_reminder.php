<?php
session_start();

// Check if the user is not logged in, redirect to login.php
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have form fields named "date", "subject", "description", "email", "contact", "sms", and "recur"
    $date = $_POST["date"];
    $subject = $_POST["subject"];
    $recur = isset($_POST["recur"]) ? $_POST["recur"] : [];

    // Validate and sanitize the input (you should improve this part)
    $date = htmlspecialchars($date);
    $subject = htmlspecialchars($subject);

    // Process the selected checkboxes for recurrence
    $selectedRecur = implode(", ", $recur);

    // Replace with your database connection details
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "remainder_system";

    $conn = new mysqli($host, $username, $password, $database);


    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Replace 'reminders' with the actual table name in your database
    $sql = "INSERT INTO reminders (date, subject,recur) 
            VALUES ('$date', '$subject', '$selectedRecur')";

    if ($conn->query($sql) === true) {
        // Reminder added successfully
        $successMessage = "Reminder set successfully!";
    } else {
        // Error adding the reminder
        $errorMessage = "Error: " . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set a new Reminder</title>
    <!-- Your CSS styles here -->  <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .reminder-container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        .reminder-container h2 {
            margin-bottom: 20px;
        }

        .reminder-container label {
            display: block;
            margin-top: 10px;
        }

        .reminder-container input,
        .reminder-container select,
        .reminder-container textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .reminder-container button {
            width: 100%;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        .reminder-container button:hover {
            background-color: #45a049;
        }

        .success-message,
        .error-message {
            margin-top: 10px;
            color: #333;
            font-weight: bold;
        }

        .success-message {
            color: #4caf50;
        }

        .error-message {
            color: #ff0000;
        }

        a {
            text-decoration: none;
            color: #333;
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="reminder-container">
        <h2>Set a new Reminder</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="date">Select a Date:</label>
            <input type="date" name="date" required>
            
            <label for="subject">Subject:</label>
            <select name="subject" required>
                <option value="Work-out">Work-out</option>
                <option value="birthday date">birthday date</option>
                <option value="daily routine">daily routine</option>
                <!-- Add more subjects as needed -->
            </select>

            
            <label>Recur for next:</label>
            <input type="checkbox" name="recur[]" value="7"> 7 Days
            <input type="checkbox" name="recur[]" value="5"> 5 Days
            <input type="checkbox" name="recur[]" value="3"> 3 Days
            <input type="checkbox" name="recur[]" value="2"> 2 Days

            <button type="submit">Set Reminder</button>
        </form>
        <div class="button">
            <button type="submit"><a href="home.php">Back</a></button>
            <button type="submit"><a href="logout.php">logout</a></button>
        </div>
        <?php
        if (isset($successMessage)) {
            echo "<div class='success-message'>$successMessage</div>";
        }
        if (isset($errorMessage)) {
            echo "<div class='error-message'>$errorMessage</div>";
        }
        ?>
    </div>

</body>
</html>
